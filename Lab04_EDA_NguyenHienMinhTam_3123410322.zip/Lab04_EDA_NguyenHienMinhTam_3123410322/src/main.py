# ==============================
# 1. Load dataset & kiểm tra thông tin
# ==============================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import IsolationForest

sns.set(style="whitegrid")

# Đọc dữ liệu
file_path = "C:\\Users\\hienm\\OneDrive\\Desktop\\Lab04_EDA_NguyenHienMinhTam_3123410322\\data\\pima-indians-diabetes.csv"
columns = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
           "Insulin", "BMI", "DiabetesPedigreeFunction", "Age", "Outcome"]
df = pd.read_csv(file_path, header=None)
df.columns = columns

print("Kích thước dữ liệu:", df.shape)
print(df.info())
df.head()

# ==============================
# 2. Kiểm tra giá trị thiếu
# ==============================
zero_as_missing_cols = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]

print("Số lượng giá trị 0 (coi là missing):")
for c in zero_as_missing_cols:
    print(f"{c}: {(df[c]==0).sum()}")

# Thay 0 bằng NaN
df2 = df.copy()
for c in zero_as_missing_cols:
    df2[c] = df2[c].replace(0, np.nan)

print("\nMissing values sau khi thay 0 -> NaN:")
print(df2.isnull().sum())

# ==============================
# 3. Xử lý missing (imputation)
# ==============================
df_imputed = df2.copy()
for c in zero_as_missing_cols:
    median_val = df_imputed[c].median()
    df_imputed[c] = df_imputed[c].fillna(median_val)
    print(f"Imputed {c} with median = {median_val:.2f}")

print("\nMissing values sau imputation:")
print(df_imputed.isnull().sum())

# Lưu file mới
df_imputed.to_csv("pima_clean_imputed.csv", index=False)
print("Saved cleaned dataset to pima_clean_imputed.csv")

# Danh sách biến số (loại bỏ Outcome, anomaly)
features = [c for c in df_imputed.columns if c not in ["Outcome", "anomaly"]]

# ==============================
# 4. Phân tích đơn biến & đa biến
# ==============================

# Histogram
df_imputed.hist(bins=20, figsize=(12,10))
plt.suptitle("Histograms (sau khi imputation)", fontsize=16)
plt.show()

# Boxplot theo Outcome
plt.figure(figsize=(14,10))
for i, c in enumerate(features, 1):
    plt.subplot(3,3,i)
    sns.boxplot(data=df_imputed, x="Outcome", y=c)
plt.tight_layout()
plt.show()

# Correlation heatmap
plt.figure(figsize=(8,6))
sns.heatmap(df_imputed.corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation heatmap")
plt.show()

# ==============================
# 5. Phát hiện ngoại lệ (IQR)
# ==============================
def detect_outliers_iqr(series):
    s = series.dropna()
    Q1 = s.quantile(0.25)
    Q3 = s.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5*IQR
    upper = Q3 + 1.5*IQR
    outliers = series[(series < lower) | (series > upper)]
    return len(outliers), lower, upper

for c in features:
    n_out, lo, up = detect_outliers_iqr(df_imputed[c])
    print(f"{c}: {n_out} ngoại lệ (ngưỡng < {lo:.2f} hoặc > {up:.2f})")

# ==============================
# 6. Phân bố Outcome
# ==============================
plt.figure(figsize=(5,4))
sns.countplot(data=df_imputed, x="Outcome", palette="Set2")
plt.title("Phân bố Outcome (0 = Không ĐTĐ, 1 = ĐTĐ)", fontsize=14)
plt.show()

# ==============================
# 7. So sánh phân phối Glucose và BMI theo Outcome
# ==============================
plt.figure(figsize=(12,5))

plt.subplot(1,2,1)
sns.kdeplot(data=df_imputed, x="Glucose", hue="Outcome", fill=True, common_norm=False, alpha=0.5)
plt.title("Phân phối Glucose theo Outcome")

plt.subplot(1,2,2)
sns.kdeplot(data=df_imputed, x="BMI", hue="Outcome", fill=True, common_norm=False, alpha=0.5)
plt.title("Phân phối BMI theo Outcome")

plt.tight_layout()
plt.show()

# ==============================
# 8. Scatter plot Glucose vs Age theo Outcome
# ==============================
plt.figure(figsize=(7,5))
sns.scatterplot(data=df_imputed, x="Age", y="Glucose", hue="Outcome", alpha=0.7)
plt.title("Scatterplot Age vs Glucose theo Outcome")
plt.show()

# ==============================
# 9. Pairplot cho vài biến chính
# ==============================
sns.pairplot(df_imputed[["Glucose", "BMI", "Age", "Outcome"]], hue="Outcome", diag_kind="kde", palette="Set1")
plt.suptitle("Pairplot biến chính theo Outcome", y=1.02, fontsize=14)
plt.show()

# ==============================
# 10. Phát hiện mẫu bất thường (Anomaly Detection)
# ==============================
iso = IsolationForest(contamination=0.05, random_state=42)
df_imputed["anomaly"] = iso.fit_predict(df_imputed.drop(columns=["Outcome"]))

print("\nKết quả phát hiện anomaly:")
print(df_imputed["anomaly"].value_counts())

print("\nMột vài mẫu bất thường được phát hiện:")
print(df_imputed[df_imputed["anomaly"]==-1].head())

# Trực quan hóa anomalies (Glucose vs BMI)
plt.figure(figsize=(7,5))
sns.scatterplot(data=df_imputed, x="Glucose", y="BMI",
                hue="anomaly", palette={1:"blue", -1:"red"}, alpha=0.7)
plt.title("Isolation Forest - Phát hiện mẫu bất thường (Glucose vs BMI)")
plt.show()

# ==============================
# Biểu đồ violin cho từng biến vs Outcome
# ==============================
num_cols = [c for c in df_imputed.columns if c not in ["Outcome", "anomaly"]]

fig, axes = plt.subplots(nrows=4, ncols=2, figsize=(15, 20), constrained_layout=True)
axes = axes.flatten()

for i, c in enumerate(num_cols):
    sns.violinplot(
        data=df_imputed, x="Outcome", y=c,
        palette="Set2", inner="quartile", ax=axes[i], cut=0
    )
    sns.stripplot(
        data=df_imputed, x="Outcome", y=c,
        color="black", size=1.5, alpha=0.4, ax=axes[i]
    )
    axes[i].set_title(f"{c} vs Outcome", fontsize=14, fontweight="bold")

fig.suptitle("Tương quan từng yếu tố với Outcome", fontsize=20, fontweight="bold")
plt.show()


# ==============================
# Biểu đồ nổi bật cho 4 biến quan trọng vs Outcome
# ==============================
important_cols = ["Glucose", "BMI", "Age", "DiabetesPedigreeFunction"]

sns.set_theme(style="whitegrid", font_scale=1.3)

fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(14, 10))
axes = axes.flatten()

for i, c in enumerate(important_cols):
    sns.violinplot(
        data=df_imputed, x="Outcome", y=c,
        palette="Set1", inner="quartile", ax=axes[i]
    )
    sns.stripplot(
        data=df_imputed, x="Outcome", y=c,
        color="black", size=2, alpha=0.4, ax=axes[i]
    )
    axes[i].set_title(f"{c} vs Outcome", fontsize=15, fontweight="bold")
    axes[i].set_xlabel("Outcome (0 = Không ĐTĐ, 1 = ĐTĐ)")
    axes[i].set_ylabel(c)

plt.suptitle("Các yếu tố ảnh hưởng mạnh nhất đến Outcome", fontsize=18, fontweight="bold", y=0.98)
plt.tight_layout()
plt.show()