# Import thư viện
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Đọc dữ liệu
wine_data = pd.read_csv("C:\\Users\\hienm\\OneDrive\\Desktop\\lab05\\winequality-red.csv") 

# Xem qua dữ liệu
print(wine_data.head())

# Thêm biến mới: Chuyển cột quality thành nhãn (low, medium, high)
wine_data['quality_label'] = wine_data['quality'].apply(
    lambda x: 'low' if x <= 4 else ('medium' if x <= 6 else 'high')
)

# ------------------ Matplotlib ------------------
# Case 1: Basic
plt.figure(figsize=(8,5))
plt.hist(wine_data['quality'], bins=7, color='skyblue', edgecolor='black')
plt.show()

# Case 2: Advanced 1
plt.figure(figsize=(8,5))
plt.hist(wine_data['quality'], bins=7, color='tomato', edgecolor='black')
plt.xlabel("Wine Quality Score", fontsize=12)
plt.ylabel("Count", fontsize=12)
plt.title("Distribution of Wine Quality", fontsize=15)
plt.show()

# Case 3: Advanced 2 - Subplots
fig, ax = plt.subplots(1,2, figsize=(15,6))
# Quality distribution
ax[0].hist(wine_data['quality'], bins=7, color='green', edgecolor='black')
ax[0].set_title("Wine Quality Distribution")
# Alcohol vs Quality
ax[1].scatter(wine_data['alcohol'], wine_data['quality'], alpha=0.5, color="purple")
ax[1].set_xlabel("Alcohol")
ax[1].set_ylabel("Quality")
ax[1].set_title("Alcohol vs Wine Quality")
plt.show()

# ------------------ Seaborn ------------------
# Case 1: Basic
plt.figure(figsize=(8,5))
sns.countplot(data=wine_data, x="quality", palette="Set2")

# Case 2: Advanced 1
plt.figure(figsize=(8,5))
sns.countplot(data=wine_data, x="quality_label", palette="viridis")
plt.title("Wine Quality Categories")
plt.xlabel("Quality Label")
plt.ylabel("Count")

# Case 3: Multiple perspectives
fig, ax = plt.subplots(1,2, figsize=(15,6))
sns.boxplot(data=wine_data, x="quality_label", y="alcohol", palette="pastel", ax=ax[0])
ax[0].set_title("Alcohol by Wine Quality Label")
sns.boxplot(data=wine_data, x="quality_label", y="volatile acidity", palette="Set3", ax=ax[1])
ax[1].set_title("Volatile Acidity by Wine Quality Label")
plt.show()
