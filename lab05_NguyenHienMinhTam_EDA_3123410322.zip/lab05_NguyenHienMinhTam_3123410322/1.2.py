# =========================================================
# BÀI TOÁN 2: PIMA INDIANS DIABETES
# =========================================================

# NHIỆM VỤ 1: Thống kê mô tả (EDA 4 bước)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
# 1. Import & xem dữ liệu
diabetes_data = pd.read_csv("diabetes.csv")
print("Diabetes shape:", diabetes_data.shape)
print(diabetes_data.head())
print(diabetes_data.info())

# 2. Làm sạch dữ liệu
diabetes_data = diabetes_data.drop_duplicates()
cols_with_zero = ["Glucose","BloodPressure","SkinThickness","Insulin","BMI"]
for col in cols_with_zero:
    diabetes_data[col] = diabetes_data[col].replace(0, np.nan)
    diabetes_data[col].fillna(diabetes_data[col].median(), inplace=True)

print("Missing values sau xử lý:\n", diabetes_data.isnull().sum())

# 3. Thống kê mô tả
desc_stats_diabetes = diabetes_data.describe().T
desc_stats_diabetes["variance"] = diabetes_data.var()
desc_stats_diabetes["mode"] = diabetes_data.mode().iloc[0]
desc_stats_diabetes["range"] = diabetes_data.max() - diabetes_data.min()
desc_stats_diabetes["IQR"] = diabetes_data.quantile(0.75) - diabetes_data.quantile(0.25)
print(desc_stats_diabetes)

# Ví dụ chi tiết cho Outcome
outcome = diabetes_data["Outcome"]
print("Outcome - Mean:", np.mean(outcome))
print("Median:", np.median(outcome))
print("Mode:", stats.mode(outcome, keepdims=True).mode[0])
print("Variance:", np.var(outcome))
print("Std Dev:", np.std(outcome))
print("Range:", np.max(outcome)-np.min(outcome))
print("Quartiles:", np.quantile(outcome, [0.25, 0.5, 0.75]))
print("IQR:", stats.iqr(outcome))

# 4. Trực quan hóa
plt.figure(figsize=(6,4))
sns.countplot(x="Outcome", data=diabetes_data, palette="Set2")
plt.title("Phân phối bệnh tiểu đường (0=Không, 1=Có)")
plt.show()

plt.figure(figsize=(10,6))
sns.heatmap(diabetes_data.corr(), cmap="coolwarm")
plt.title("Ma trận tương quan - Diabetes")
plt.show()

print("So sánh trung bình theo Outcome:\n", diabetes_data.groupby("Outcome").mean())


# NHIỆM VỤ 2: Khám phá & xử lý dữ liệu
diabetes_data = pd.read_csv("diabetes.csv")
diabetes_data = diabetes_data[['Pregnancies','Glucose','BloodPressure',
                               'SkinThickness','Insulin','BMI',
                               'DiabetesPedigreeFunction','Age','Outcome']]

# 1. Remove duplicates
diabetes_data_duplicate = diabetes_data.drop_duplicates()
diabetes_data = diabetes_data.drop(labels=[1], axis=0)       # xóa 1 dòng
diabetes_data = diabetes_data.drop(labels=['SkinThickness'], axis=1)  # xóa 1 cột

# 2. Replace & change format
diabetes_data['Outcome_replaced'] = diabetes_data['Outcome'].replace([0,1],['No','Yes'])
diabetes_data['Glucose'] = diabetes_data['Glucose'].fillna(0)
diabetes_data['Outcome_changed'] = diabetes_data['Outcome'].astype(int)

# 3. Handle missing values
print(diabetes_data.isnull().sum())
diabetes_data_withoutna = diabetes_data.dropna(how='any')
print("Diabetes shape sau drop NA:", diabetes_data_withoutna.shape)