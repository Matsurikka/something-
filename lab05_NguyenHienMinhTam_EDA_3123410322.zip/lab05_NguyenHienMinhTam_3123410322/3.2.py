from autoviz.AutoViz_Class import AutoViz_Class
import pandas as pd

# Khởi tạo AutoViz
AV = AutoViz_Class()

# Đọc dữ liệu
df = pd.read_csv(r"C:\\Users\\hienm\\OneDrive\\Desktop\\lab05\\marketing_campaign.csv")

# Sinh báo cáo AutoViz
AV.AutoViz(
    filename="",   # không cần file path vì đã truyền df
    dfte=df,
    chart_format="svg",
    verbose=2
)
