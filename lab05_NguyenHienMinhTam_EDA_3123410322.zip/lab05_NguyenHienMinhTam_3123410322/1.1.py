# =========================================================
# BÀI TOÁN 1: RED WINE QUALITY
# =========================================================

# NHIỆM VỤ 1: Thống kê mô tả (EDA 4 bước)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# 1. Import & xem dữ liệu
wine_data = pd.read_csv("C:\\Users\\hienm\\OneDrive\\Desktop\\lab05\\winequality-red.csv")
print("Wine shape:", wine_data.shape)
print(wine_data.head())
print(wine_data.info())

# 2. Làm sạch dữ liệu
wine_data = wine_data.drop_duplicates()
print("Sau khi bỏ trùng:", wine_data.shape)
print("Missing values:\n", wine_data.isnull().sum())

# 3. Thống kê mô tả
desc_stats_wine = wine_data.describe().T
desc_stats_wine["variance"] = wine_data.var()
desc_stats_wine["mode"] = wine_data.mode().iloc[0]
desc_stats_wine["range"] = wine_data.max() - wine_data.min()
desc_stats_wine["IQR"] = wine_data.quantile(0.75) - wine_data.quantile(0.25)
print(desc_stats_wine)

# Ví dụ chi tiết cho quality
quality = wine_data["quality"]
print("Quality - Mean:", np.mean(quality))
print("Median:", np.median(quality))
print("Mode:", stats.mode(quality, keepdims=True).mode[0])
print("Variance:", np.var(quality))
print("Std Dev:", np.std(quality))
print("Range:", np.max(quality)-np.min(quality))
print("Quartiles:", np.quantile(quality, [0.25, 0.5, 0.75]))
print("IQR:", stats.iqr(quality))

# 4. Trực quan hóa
plt.figure(figsize=(8,5))
sns.countplot(x="quality", data=wine_data, palette="viridis")
plt.title("Phân phối chất lượng rượu đỏ")
plt.show()

plt.figure(figsize=(10,6))
sns.heatmap(wine_data.corr(), cmap="coolwarm")
plt.title("Ma trận tương quan - Wine Quality")
plt.show()


# NHIỆM VỤ 2: Khám phá & xử lý dữ liệu
wine_data = pd.read_csv("winequality-red.csv")
wine_data = wine_data[['fixed acidity','volatile acidity','citric acid',
                       'residual sugar','chlorides','free sulfur dioxide',
                       'total sulfur dioxide','density','pH','sulphates',
                       'alcohol','quality']]

# 1. Remove duplicates
wine_data_duplicate = wine_data.drop_duplicates()
wine_data = wine_data.drop(labels=[1], axis=0)          # xóa 1 dòng
wine_data = wine_data.drop(labels=['density'], axis=1)  # xóa 1 cột

# 2. Replace & change format
wine_data['quality_replaced'] = wine_data['quality'].replace(
    [3,4,5,6,7,8],
    ['poor','poor','average','average','good','excellent']
)
wine_data['alcohol'] = wine_data['alcohol'].fillna(0)
wine_data['quality_changed'] = wine_data['quality'].astype(int)

# 3. Handle missing values
print(wine_data.isnull().sum())
wine_data_withoutna = wine_data.dropna(how='any')
print("Wine shape sau drop NA:", wine_data_withoutna.shape)