# Import thư viện
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ================= DIABETES ==================
# Đọc dữ liệu
diabetes_data = pd.read_csv("C:\\Users\\hienm\\OneDrive\\Desktop\\lab05\\diabetes.csv")

print(diabetes_data.head())

# Matplotlib - Case 1
plt.figure(figsize=(8,5))
plt.hist(diabetes_data['Glucose'], bins=20, color='skyblue', edgecolor='black')
plt.title("Glucose Distribution")
plt.show()

# Case 2
plt.figure(figsize=(8,5))
plt.hist(diabetes_data['BMI'], bins=20, color='orange', edgecolor='black')
plt.title("BMI Distribution")
plt.xlabel("BMI")
plt.ylabel("Count")
plt.show()

# Case 3 - Subplots
fig, ax = plt.subplots(1,2, figsize=(15,6))
ax[0].hist(diabetes_data['Age'], bins=15, color='teal', edgecolor='black')
ax[0].set_title("Age Distribution")
ax[1].scatter(diabetes_data['Glucose'], diabetes_data['BMI'], alpha=0.5, color="purple")
ax[1].set_xlabel("Glucose")
ax[1].set_ylabel("BMI")
ax[1].set_title("Glucose vs BMI")
plt.show()

# Seaborn
plt.figure(figsize=(8,5))
sns.countplot(data=diabetes_data, x="Outcome", palette="Set2")
plt.title("Diabetes Outcome (0 = No, 1 = Yes)")

fig, ax = plt.subplots(1,2, figsize=(15,6))
sns.boxplot(data=diabetes_data, x="Outcome", y="Glucose", palette="coolwarm", ax=ax[0])
ax[0].set_title("Glucose vs Diabetes Outcome")
sns.boxplot(data=diabetes_data, x="Outcome", y="BMI", palette="Set3", ax=ax[1])
ax[1].set_title("BMI vs Diabetes Outcome")
plt.show()


# ================= RETAIL ==================
# Đọc dữ liệu
retail_data = pd.read_excel("C:\\Users\\hienm\\OneDrive\\Desktop\\lab05\\Online Retail.xlsx")

print(retail_data.head())

# Tiền xử lý: bỏ NA và tạo biến doanh thu
retail_data = retail_data.dropna()
retail_data['TotalPrice'] = retail_data['Quantity'] * retail_data['UnitPrice']

# Matplotlib - Case 1
plt.figure(figsize=(8,5))
plt.hist(retail_data['Quantity'], bins=50, color='lightgreen', edgecolor='black')
plt.title("Distribution of Quantity Ordered")
plt.show()

# Case 2
plt.figure(figsize=(8,5))
top_customers = retail_data.groupby('CustomerID')['TotalPrice'].sum().nlargest(10)
plt.bar(top_customers.index.astype(str), top_customers.values, color='coral')
plt.title("Top 10 Customers by Spending")
plt.xticks(rotation=45)
plt.show()

# Case 3 - Subplots
fig, ax = plt.subplots(1,2, figsize=(15,6))
top_products = retail_data.groupby('Description')['Quantity'].sum().nlargest(10)
ax[0].barh(top_products.index, top_products.values, color='purple')
ax[0].set_title("Top 10 Bestselling Products")
top_countries = retail_data.groupby('Country')['TotalPrice'].sum().nlargest(10)
ax[1].bar(top_countries.index, top_countries.values, color='navy')
ax[1].set_title("Top 10 Countries by Revenue")
plt.xticks(rotation=45)
plt.show()

# Seaborn
plt.figure(figsize=(8,5))
sns.histplot(retail_data['TotalPrice'], bins=50, kde=True, color="skyblue")
plt.title("Distribution of Transaction Values")

fig, ax = plt.subplots(1,2, figsize=(15,6))
sns.barplot(x=top_products.values, y=top_products.index, palette="viridis", ax=ax[0])
ax[0].set_title("Top 10 Products (Seaborn)")
sns.barplot(x=top_countries.index, y=top_countries.values, palette="Set2", ax=ax[1])
ax[1].set_title("Top 10 Countries (Seaborn)")
plt.xticks(rotation=45)
plt.show()
