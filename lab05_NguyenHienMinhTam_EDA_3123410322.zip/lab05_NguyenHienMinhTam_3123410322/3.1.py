import sweetviz as sv
import pandas as pd

# Đọc dữ liệu
df = pd.read_csv("C:\\Users\\hienm\\OneDrive\\Desktop\\lab05\\marketing_campaign.csv", sep="\t")

# Tạo báo cáo Sweetviz
report = sv.analyze(df)

# Xuất ra file HTML
report.show_html("C:\\Users\\hienm\\OneDrive\\Desktop\\lab05\\sweetviz_report.html")
